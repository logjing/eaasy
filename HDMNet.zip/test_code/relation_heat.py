import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from pandas import Series,DataFrame
import seaborn as sns
import palettable #python颜色库
from sklearn import datasets


plt.rcParams['font.sans-serif']=['SimHei']  # 用于显示中文
plt.rcParams['axes.unicode_minus'] = False  # 用于显示中文

iris=datasets.load_iris()
x, y = iris.data, iris.target
pd_iris = pd.DataFrame(np.hstack((x, y.reshape(150, 1))),columns=['sepal length(cm)','sepal width(cm)','petal length(cm)','petal width(cm)','class'] )

plt.figure(dpi=200, figsize=(3,2))
# data1 = np.array(pd_iris['sepal length(cm)']).reshape(25,6)#Series转np.array
# data1 = np.random.random((6,6))*0.3
# for i in range(6):
#     data1[i][i] = 1
# matplotlib.axes.Axes.imshow
data1 = np.array([
    [0.6, 0.9],
    [0.3, 0.05],
    [0.2, 0.1]
])
df = pd.DataFrame(data1,
                  index=[chr(i) for i in range(87, 90)],#DataFrame的行标签设置为大写字母
                  columns=["a","b"])#设置DataFrame的列标签


# plt.figure(dpi=120)
sns.heatmap(data=df, cmap='YlGnBu', linewidths=0.5 #矩阵数据集，数据的index和columns分别为heatmap的y轴方向和x轴方向标签
         )
plt.title('所有参数默认')
plt.show()